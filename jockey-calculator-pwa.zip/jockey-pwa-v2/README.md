# The Jockey Calculator — PWA Deployment Guide

## What's in this folder
- `public/index.html` — The complete app
- `public/manifest.json` — Makes it installable as an app
- `public/sw.js` — Service worker for offline use
- `public/icon-192.png` — App icon (small)
- `public/icon-512.png` — App icon (large)
- `vercel.json` — Hosting config

---

## Step 1: Create a GitHub account
Go to https://github.com and sign up (free).

## Step 2: Create a new repository
1. Click **+** → **New repository**
2. Name it: `jockey-calculator`
3. Set to **Public**
4. Click **Create repository**

## Step 3: Upload the files
1. On the repo page click **uploading an existing file**
2. Upload ALL files — make sure to keep the folder structure:
   - `public/index.html`
   - `public/manifest.json`
   - `public/sw.js`
   - `public/icon-192.png`
   - `public/icon-512.png`
   - `vercel.json`
3. Click **Commit changes**

## Step 4: Deploy on Vercel
1. Go to https://vercel.com
2. Sign up with your GitHub account
3. Click **Add New Project**
4. Select your `jockey-calculator` repo → click **Import**
5. Set **Root Directory** to `public`
6. Click **Deploy**
7. In ~60 seconds you get a URL like: `jockey-calculator.vercel.app`

## Step 5: Add to iPhone home screen
1. Open your Vercel URL in **Safari** (must be Safari, not Chrome)
2. Tap the **Share** button (box with arrow at bottom)
3. Tap **Add to Home Screen**
4. Name it **Jockey Calculator** → tap **Add**

It will appear on your home screen with a black/red icon and open full screen like a native app.

---

## Updating the app
When you get updated files from Claude:
1. Go to your GitHub repo
2. Click the file you want to update → click the pencil icon to edit
3. Or drag new files into the repo
4. Vercel automatically redeploys within 60 seconds

---

## Backup your data
Use the **📤 Export** button in the app regularly to save a backup.
Use **📥 Import** to restore on a new device.
