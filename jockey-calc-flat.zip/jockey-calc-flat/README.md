# The Jockey Calculator

## Deploy to Vercel

### Step 1: GitHub
1. Go to https://github.com → sign up free
2. Click **+** → **New repository** → name it `jockey-calculator` → **Public** → **Create**
3. Click **uploading an existing file**
4. Drag ALL files from this folder into the upload area:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `icon-192.png`
   - `icon-512.png`
   - `vercel.json`
5. Click **Commit changes**

### Step 2: Vercel
1. Go to https://vercel.com → sign up with GitHub
2. Click **Add New Project**
3. Find `jockey-calculator` → click **Import**
4. **Leave all settings as default** — do NOT change the root directory
5. Click **Deploy**
6. Wait ~60 seconds → you get a URL like `jockey-calculator.vercel.app`

### Step 3: iPhone
1. Open your URL in **Safari**
2. Tap **Share** (box with arrow) → **Add to Home Screen**
3. Tap **Add** → done!

## Updating
Replace `index.html` in GitHub → Vercel auto-redeploys in 60 seconds.
